import { type FormEvent, type ReactNode, useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  BriefcaseBusiness,
  Check,
  Clock3,
  Compass,
  Building2,
  ExternalLink,
  Home as HomeIcon,
  Instagram,
  Layers3,
  MapPin,
  Menu,
  MessageCircle,
  MoveHorizontal,
  Palette,
  Phone,
  Plus,
  Quote,
  Star,
  X,
} from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

type GalleryItem = {
  title: string;
  category: 'Living Room' | 'Bedroom' | 'Office' | 'Luxury' | 'Textured' | 'Modern' | 'Floral';
  image: string;
  note: string;
};

const googleListingUrl = 'https://maps.app.goo.gl/zkDkR2yJzbdnALtT6';
const googleListingPhoto = 'https://lh3.googleusercontent.com/gps-cs-s/AHRPTWmw8zrq-vVAwgyf4NFdl4Ig2wKEq6_oD_6gXDAG5Yc32N2T41L8quI5dFxqBv67omBxSvsz2tNscwxdBlT8BhXqb40NqciyR-GBYQHQTWhKQdZLNwGHSyT4XApAAsj4IzxH3NOz8D2vm44=w408-h544-k-no';

const galleryItems: GalleryItem[] = [
  { title: 'Indigo Canopy', category: 'Floral', image: '/images/parkview-botanical.jpg', note: 'Botanical wallcovering / living' },
  { title: 'Dusk Mineral', category: 'Bedroom', image: '/images/parkview-bedroom.jpg', note: 'Mineral texture / bedroom' },
  { title: 'Quiet Geometry', category: 'Modern', image: '/images/parkview-office.jpg', note: 'Geometric wallcovering / office' },
  { title: 'Linen & Clay', category: 'Textured', image: '/images/parkview-texture.jpg', note: 'Hand-trowelled finish / texture' },
  { title: 'The Reading Room', category: 'Living Room', image: '/images/parkview-hero.jpg', note: 'Layered botanical / living' },
  { title: 'Verandah Study', category: 'Office', image: '/images/parkview-exterior.jpg', note: 'Mineral exterior / commercial' },
  { title: 'Classic Luxury', category: 'Luxury', image: '/images/parkview-hero.jpg', note: 'Timeless layered finish / living' },
  { title: 'Modern Texture', category: 'Textured', image: '/images/parkview-office.jpg', note: 'Contemporary texture / office' },
];

const serviceItems = [
  { number: '01', title: 'Premium wallpapers', copy: 'Stylish wallpaper designs for modern and classic spaces.', icon: Palette },
  { number: '02', title: 'Interior wall solutions', copy: 'Beautiful finishes designed to enhance residential and commercial interiors.', icon: Layers3 },
  { number: '03', title: 'Exterior solutions', copy: 'Professional solutions for improving the appearance and finish of exterior spaces.', icon: Building2 },
  { number: '04', title: 'Design consultation', copy: 'Help choosing patterns, textures, colors and finishes that suit your space.', icon: Compass },
  { number: '05', title: 'Residential spaces', copy: 'Transform bedrooms, living rooms, dining areas and other home spaces.', icon: HomeIcon },
  { number: '06', title: 'Commercial spaces', copy: 'Premium wall solutions for offices, shops, studios and commercial environments.', icon: BriefcaseBusiness },
];

function scrollToSection(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [filter, setFilter] = useState<'All' | GalleryItem['category']>('All');
  const [lightbox, setLightbox] = useState<GalleryItem | null>(null);
  const [beforeAfter, setBeforeAfter] = useState<'before' | 'after'>('after');
  const [formState, setFormState] = useState({ name: '', phone: '', email: '', project: '', message: '' });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [formSent, setFormSent] = useState(false);

  useEffect(() => {
    document.title = 'PARKVIEW Interior & Exterior Solutions | Premium Wallpapers in Kanpur';
    const description = 'PARKVIEW Interior and Exterior Solutions offers premium wallpaper and interior & exterior wall solutions in Kanpur, Uttar Pradesh. Transform your space with elegant designs and quality finishes.';
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'description');
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', description);
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const filteredItems = useMemo(
    () => filter === 'All' ? galleryItems : galleryItems.filter((item) => item.category === filter),
    [filter],
  );

  const updateForm = (field: string, value: string) => {
    setFormState((current) => ({ ...current, [field]: value }));
    if (formErrors[field]) setFormErrors((current) => ({ ...current, [field]: '' }));
  };

  const submitEnquiry = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const errors: Record<string, string> = {};
    if (!formState.name.trim()) errors.name = 'Please add your name.';
    if (!/^[6-9]\d{9}$/.test(formState.phone.replace(/\D/g, ''))) errors.phone = 'Enter a valid 10-digit mobile number.';
    if (formState.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formState.email.trim())) errors.email = 'Enter a valid email address.';
    if (!formState.project) errors.project = 'Choose a project type.';
    if (!formState.message.trim()) errors.message = 'Tell us a little about the space.';
    setFormErrors(errors);
    if (Object.keys(errors).length === 0) {
      setFormSent(true);
      setFormState({ name: '', phone: '', email: '', project: '', message: '' });
    }
  };

  const navItems = [
    ['Home', 'top'],
    ['About', 'about'],
    ['Wallpapers', 'collection'],
    ['Services', 'services'],
    ['Why Parkview', 'why'],
    ['Reviews', 'reviews'],
    ['Contact', 'contact'],
  ];

  return (
    <div className="grain min-h-[100dvh] overflow-x-hidden bg-[#f3efe7] text-[#203b37]">
      <header className={`site-nav fixed inset-x-0 top-0 z-40 ${scrolled ? 'scrolled' : ''}`}>
        <div className="mx-auto flex h-[76px] max-w-[1380px] items-center justify-between px-5 sm:px-8 lg:px-12">
          <button
            type="button"
            onClick={() => scrollToSection('top')}
            className="focus-ring group flex items-center gap-3 text-left"
            data-testid="button-logo-home"
            aria-label="Go to top"
          >
            <span className="flex h-9 w-9 items-center justify-center border border-[#c67a55] text-[#c67a55]">
              <span className="font-display text-2xl leading-none">P</span>
            </span>
            <span className="hidden sm:block">
              <span className="block text-[13px] font-semibold tracking-[.18em] text-[#203b37]">PARKVIEW</span>
              <span className="block font-mono-brand text-[9px] uppercase tracking-[.13em] text-[#6f7971]">Interior + Exterior</span>
            </span>
          </button>
          <nav className="hidden items-center gap-4 lg:gap-6 md:flex" aria-label="Primary navigation">
            {navItems.map(([label, id]) => (
              <button
                key={id}
                type="button"
                onClick={() => scrollToSection(id)}
                className="focus-ring relative py-2 text-[11px] font-semibold uppercase tracking-[.14em] text-[#38524d] transition-colors hover:text-[#c67a55]"
                data-testid={`button-nav-${id}`}
              >
                {label}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <a
              href="tel:7905531183"
              className="focus-ring hidden items-center gap-2 bg-[#c67a55] px-4 py-2.5 text-[10px] font-semibold uppercase tracking-[.15em] text-[#203b37] transition-transform hover:-translate-y-1 sm:flex"
              data-testid="link-nav-call"
            >
              <Phone size={14} strokeWidth={1.7} /> Call now
            </a>
            <button
              type="button"
              onClick={() => setMenuOpen((value) => !value)}
              className="focus-ring flex h-10 w-10 items-center justify-center border border-[#203b37]/25 md:hidden"
              aria-expanded={menuOpen}
              aria-label={menuOpen ? 'Close menu' : 'Open menu'}
              data-testid="button-mobile-menu"
            >
              {menuOpen ? <X size={19} /> : <Menu size={19} />}
            </button>
          </div>
        </div>
        <AnimatePresence>
          {menuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className="border-t border-[#203b37]/10 bg-[#f3efe7] px-5 py-5 md:hidden"
            >
              <nav className="mx-auto flex max-w-[1380px] flex-col" aria-label="Mobile navigation">
                {navItems.map(([label, id]) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => { setMenuOpen(false); scrollToSection(id); }}
                    className="focus-ring border-b border-[#203b37]/10 py-4 text-left font-display text-3xl text-[#203b37]"
                    data-testid={`button-mobile-nav-${id}`}
                  >
                    {label}
                  </button>
                ))}
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <main id="top">
        <section className="relative flex min-h-[730px] items-end overflow-hidden bg-[#203b37] pt-24 text-[#f3efe7] sm:min-h-[790px]" aria-labelledby="hero-title">
          <img src="/images/parkview-hero.jpg" alt="Sunlit living room with botanical wallpaper and warm wood details" className="hero-image absolute inset-0 h-full w-full object-cover opacity-[.62]" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#102c29]/95 via-[#193b36]/70 to-[#193b36]/20" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#102c29]/80 via-transparent to-[#102c29]/10" />
          <div className="relative mx-auto grid w-full max-w-[1380px] items-end gap-12 px-5 pb-16 sm:px-8 sm:pb-20 lg:grid-cols-[1.1fr_.9fr] lg:px-12 lg:pb-24">
            <div>
              <div className="reveal-up eyebrow mb-6 flex items-center gap-3 text-[#e3af88]"><span className="h-px w-10 bg-[#e3af88]" /> Kanpur · Uttar Pradesh</div>
              <h1 id="hero-title" className="reveal-up delay-1 max-w-[720px] font-display text-[clamp(4.4rem,11vw,9.8rem)] leading-[.82] tracking-[-.045em]">
                Transform Your Walls.<br /><em>Elevate Your Space.</em>
              </h1>
              <p className="reveal-up delay-2 mt-8 max-w-[440px] text-[15px] leading-7 text-[#e6e3d9]/85 sm:text-base">
                Premium wallpaper and interior &amp; exterior solutions designed to give your spaces a distinctive, elegant finish.
              </p>
              <div className="reveal-up delay-3 mt-9 flex flex-wrap items-center gap-5">
                <button
                  type="button"
                  onClick={() => scrollToSection('collection')}
                  className="focus-ring group flex items-center gap-5 bg-[#c67a55] px-5 py-4 text-[10px] font-semibold uppercase tracking-[.16em] text-[#203b37] transition-transform hover:-translate-y-1"
                  data-testid="button-hero-collection"
                >
                  Explore wallpapers <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
                </button>
                <a href="tel:7905531183" className="focus-ring flex items-center gap-2 border-b border-[#e6e3d9]/55 pb-2 text-[10px] font-semibold uppercase tracking-[.16em] text-[#f3efe7] hover:border-[#e3af88]" data-testid="link-hero-call">
                  Call 7905531183 <Phone size={14} />
                </a>
              </div>
              <div className="reveal-up delay-4 mt-7 flex items-center gap-2 font-mono-brand text-[10px] uppercase tracking-[.14em] text-[#e3af88]" aria-label="4.8 out of 5 from 129 reviews">
                <span aria-hidden="true">★★★★★</span> 4.8/5 <span className="text-[#e6e3d9]/55">|</span> 129+ reviews
              </div>
            </div>
            <div className="reveal-up delay-4 hidden justify-self-end lg:flex lg:flex-col lg:items-end lg:gap-20">
              <div className="max-w-[210px] border-l border-[#e6e3d9]/35 pl-5 text-right text-sm leading-6 text-[#e6e3d9]/80">
                A material library for<br />homes, offices and<br />commercial spaces.
              </div>
              <div className="flex items-center gap-3 text-[#e3af88]">
                <span className="font-mono-brand text-[10px] tracking-[.15em]">SCROLL TO DISCOVER</span><ArrowDown size={15} />
              </div>
            </div>
          </div>
        </section>

        <section className="border-b border-[#203b37]/15 bg-[#e8dfd1] text-[#203b37]" aria-label="Parkview trust indicators">
          <div className="mx-auto grid max-w-[1380px] grid-cols-2 lg:grid-cols-4">
            {[
              ['4.8/5', 'Customer rating', <Star key="star" size={13} fill="currentColor" />],
              ['129+', 'Happy reviews', null],
              ['Premium', 'Wall solutions', null],
              ['Kanpur', 'Based business', <MapPin key="pin" size={13} />],
            ].map(([value, label, icon], index) => (
              <div key={String(label)} className={`flex min-h-[110px] items-center gap-3 px-5 py-5 sm:px-8 lg:min-h-[130px] lg:px-12 ${index < 3 ? 'border-r border-[#203b37]/15' : ''}`}>
                {icon && <span className="text-[#c67a55]">{icon}</span>}
                <div><p className="font-display text-2xl sm:text-3xl">{value}</p><p className="eyebrow mt-1 text-[#61706a]">{label}</p></div>
              </div>
            ))}
          </div>
        </section>

        <section id="about" className="scroll-mt-24 bg-[#f3efe7] px-5 py-24 sm:px-8 sm:py-32 lg:px-12 lg:py-40">
          <div className="mx-auto grid max-w-[1380px] gap-16 lg:grid-cols-[.75fr_1.25fr] lg:gap-24">
            <div>
              <p className="eyebrow flex items-center gap-3 text-[#c67a55]"><span className="h-px w-8 bg-[#c67a55]" /> The Parkview point of view</p>
              <h2 className="mt-7 max-w-[440px] font-display text-[clamp(3.5rem,6vw,6.2rem)] leading-[.86] tracking-[-.035em]">Beautiful spaces<br /><em>begin with beautiful walls.</em></h2>
            </div>
            <div className="grid items-end gap-10 md:grid-cols-[1fr_1.1fr]">
              <div>
                <p className="max-w-[450px] text-lg leading-8 text-[#38524d]">Parkview is a material-first interior and exterior solutions showroom in Kanpur. We help you find the surface that makes the rest of the room make sense.</p>
                <p className="mt-5 max-w-[420px] text-sm leading-7 text-[#6f7971]">From the first swatch to the final edge, our approach is practical, personal and quietly exacting. No catalogue overwhelm. Just a considered edit, made for your light, your architecture and the way you live.</p>
                <button type="button" onClick={() => scrollToSection('contact')} className="focus-ring mt-8 inline-flex items-center gap-3 border-b border-[#203b37] pb-2 text-[10px] font-semibold uppercase tracking-[.15em]" data-testid="button-about-services">Talk to our team <ArrowRight size={15} /></button>
              </div>
              <div className="relative aspect-[.78] overflow-hidden bg-[#d4c6b5]">
                <img src="/images/parkview-texture.jpg" alt="Close-up of layered sand and terracotta wall texture" loading="lazy" className="h-full w-full object-cover transition-transform duration-700 hover:scale-105" />
                <div className="absolute bottom-4 left-4 bg-[#f3efe7] px-3 py-2 font-mono-brand text-[9px] uppercase tracking-[.1em] text-[#203b37]">Material study / 04</div>
              </div>
            </div>
          </div>
        </section>

        <section id="collection" className="scroll-mt-24 bg-[#203b37] px-5 py-24 text-[#f3efe7] sm:px-8 sm:py-32 lg:px-12" aria-labelledby="collection-title">
          <div className="mx-auto max-w-[1380px]">
            <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
              <div><p className="eyebrow flex items-center gap-3 text-[#e3af88]"><span className="h-px w-8 bg-[#e3af88]" /> The material library</p><h2 id="collection-title" className="mt-7 max-w-[800px] font-display text-[clamp(3.5rem,7vw,7.2rem)] leading-[.82] tracking-[-.04em]">Discover Your<br /><em>Perfect Wall</em></h2></div>
              <p className="max-w-[300px] text-sm leading-6 text-[#cbd0c6]/75">Textures, patterns and finishes that transform ordinary spaces into extraordinary ones.</p>
            </div>
            <div className="mt-12 flex flex-wrap gap-2 border-b border-[#e6e3d9]/20 pb-4" role="group" aria-label="Filter collection">
              {(['All', 'Living Room', 'Bedroom', 'Office', 'Luxury', 'Textured', 'Modern', 'Floral'] as const).map((category) => (
                <button key={category} type="button" onClick={() => setFilter(category)} className={`focus-ring px-4 py-2 text-[10px] font-semibold uppercase tracking-[.14em] transition-colors ${filter === category ? 'bg-[#c67a55] text-[#203b37]' : 'text-[#cbd0c6]/70 hover:text-[#f3efe7]'}`} data-testid={`button-filter-${category.toLowerCase()}`} aria-pressed={filter === category}>{category}</button>
              ))}
            </div>
            <motion.div layout className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <AnimatePresence mode="popLayout">
                {filteredItems.map((item, index) => (
                  <motion.button
                    layout
                    key={item.title}
                    type="button"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 15 }}
                    transition={{ duration: .35, delay: index * .04 }}
                    onClick={() => setLightbox(item)}
                    className={`focus-ring group relative overflow-hidden text-left ${index === 0 ? 'sm:row-span-2' : ''}`}
                    data-testid={`button-gallery-${item.title.toLowerCase().replaceAll(' ', '-')}`}
                  >
                    <div className={`overflow-hidden bg-[#304c47] ${index === 0 ? 'aspect-[.72] h-full' : 'aspect-[1.15]'}`}>
                      <img src={item.image} alt={`${item.title}, ${item.note}`} loading={index > 1 ? 'lazy' : undefined} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                    </div>
                    <div className="absolute inset-x-0 bottom-0 flex items-end justify-between bg-gradient-to-t from-[#102c29]/85 to-transparent p-5 pt-16">
                      <div><p className="font-display text-2xl">{item.title}</p><p className="eyebrow mt-1 text-[#d7b18e]">{item.category}</p></div><span className="flex h-9 w-9 items-center justify-center border border-[#f3efe7]/50 transition-colors group-hover:bg-[#c67a55] group-hover:text-[#203b37]"><Plus size={16} /></span>
                    </div>
                  </motion.button>
                ))}
              </AnimatePresence>
            </motion.div>
            <div className="mt-12 flex items-center justify-between border-t border-[#e6e3d9]/20 pt-5"><p className="font-mono-brand text-[10px] uppercase tracking-[.13em] text-[#cbd0c6]/60">Tap any image to enlarge</p><button type="button" onClick={() => scrollToSection('contact')} className="focus-ring flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[.15em] text-[#e3af88]" data-testid="button-collection-enquire">Find your finish <ArrowUpRight size={15} /></button></div>
          </div>
        </section>

        <section className="bg-[#d4c6b5] px-5 py-24 sm:px-8 sm:py-32 lg:px-12" aria-labelledby="google-photo-title">
          <div className="mx-auto grid max-w-[1380px] gap-12 lg:grid-cols-[.8fr_1.2fr] lg:items-center lg:gap-24">
            <div>
              <p className="eyebrow flex items-center gap-3 text-[#c67a55]"><span className="h-px w-8 bg-[#c67a55]" /> From Google Maps</p>
              <h2 id="google-photo-title" className="mt-7 max-w-[470px] font-display text-[clamp(3.5rem,6vw,6.1rem)] leading-[.84] tracking-[-.035em]">See the<br /><em>PARKVIEW studio.</em></h2>
              <p className="mt-7 max-w-[390px] text-sm leading-6 text-[#38524d]">A real photo from our Google Business listing, so you can recognise the showroom when you visit us in Juhi Kalan.</p>
              <a href={googleListingUrl} target="_blank" rel="noreferrer" className="focus-ring mt-8 inline-flex items-center gap-3 border-b border-[#203b37] pb-2 text-[10px] font-semibold uppercase tracking-[.15em]" data-testid="link-google-photos">See all Google photos <ExternalLink size={15} /></a>
            </div>
            <a href={googleListingUrl} target="_blank" rel="noreferrer" className="focus-ring group relative block max-w-[520px] justify-self-end overflow-hidden bg-[#203b37] p-3" data-testid="link-google-listing-photo">
              <div className="relative overflow-hidden">
                <img src={googleListingPhoto} alt="PARKVIEW Interior & Exterior Solutions storefront photo from Google Maps" loading="lazy" className="aspect-[1.28] h-full w-full object-cover object-center transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute inset-x-0 bottom-0 flex items-end justify-between bg-gradient-to-t from-[#102c29]/90 to-transparent p-5 pt-16 text-[#f3efe7]">
                  <div><p className="font-display text-3xl">The PARKVIEW showroom</p><p className="eyebrow mt-1 text-[#e3af88]">Google Maps photo · Juhi Kalan</p></div>
                  <span className="flex h-9 w-9 items-center justify-center border border-[#f3efe7]/55 transition-colors group-hover:bg-[#c67a55] group-hover:text-[#203b37]"><ArrowUpRight size={16} /></span>
                </div>
              </div>
            </a>
          </div>
        </section>

        <section id="services" className="scroll-mt-24 bg-[#e8dfd1] px-5 py-24 sm:px-8 sm:py-32 lg:px-12" aria-labelledby="services-title">
          <div className="mx-auto max-w-[1380px]">
            <div className="grid gap-10 lg:grid-cols-[.7fr_1.3fr]">
              <div><p className="eyebrow flex items-center gap-3 text-[#c67a55]"><span className="h-px w-8 bg-[#c67a55]" /> What we bring</p><h2 id="services-title" className="mt-7 max-w-[370px] font-display text-[clamp(3.5rem,6vw,6.1rem)] leading-[.86] tracking-[-.035em]">From swatch<br />to <em>space.</em></h2></div>
              <div className="border-t border-[#203b37]/25">
                {serviceItems.map((service) => (
                  <div key={service.number} className="group grid gap-4 border-b border-[#203b37]/25 py-7 transition-colors hover:bg-[#f3efe7]/55 md:grid-cols-[70px_1fr_1.2fr] md:items-center md:gap-8">
                    <span className="flex items-center gap-3 font-mono-brand text-[10px] text-[#c67a55]"><span className="flex h-8 w-8 items-center justify-center border border-[#c67a55]/40"><service.icon size={15} strokeWidth={1.5} /></span>{service.number}</span><h3 className="font-display text-3xl">{service.title}</h3><p className="max-w-[370px] text-sm leading-6 text-[#61706a]">{service.copy}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="bg-[#f3efe7] px-5 py-24 sm:px-8 sm:py-32 lg:px-12" aria-labelledby="transformation-title">
          <div className="mx-auto max-w-[1380px]">
            <div className="mb-10 flex flex-col justify-between gap-6 md:flex-row md:items-end"><div><p className="eyebrow flex items-center gap-3 text-[#c67a55]"><span className="h-px w-8 bg-[#c67a55]" /> The shift</p><h2 id="transformation-title" className="mt-7 font-display text-[clamp(3.5rem,6.5vw,6.5rem)] leading-[.83] tracking-[-.035em]">A wall can change<br /><em>the whole room.</em></h2></div><div className="flex items-center gap-2 self-start border border-[#203b37]/20 p-1 md:self-end"><button type="button" onClick={() => setBeforeAfter('before')} className={`focus-ring px-4 py-2 font-mono-brand text-[9px] uppercase tracking-[.13em] ${beforeAfter === 'before' ? 'bg-[#203b37] text-[#f3efe7]' : 'text-[#61706a]'}`} data-testid="button-transformation-before">Before</button><button type="button" onClick={() => setBeforeAfter('after')} className={`focus-ring px-4 py-2 font-mono-brand text-[9px] uppercase tracking-[.13em] ${beforeAfter === 'after' ? 'bg-[#c67a55] text-[#203b37]' : 'text-[#61706a]'}`} data-testid="button-transformation-after">After</button></div></div>
            <div className="relative overflow-hidden bg-[#d4c6b5]"><AnimatePresence mode="wait"><motion.div key={beforeAfter} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="relative aspect-[1.65] sm:aspect-[2.4]"><img src={beforeAfter === 'after' ? '/images/parkview-hero.jpg' : '/images/parkview-texture.jpg'} alt={beforeAfter === 'after' ? 'Finished living room transformation with botanical wallpaper' : 'Close view of a neutral wall before its finish is applied'} className={`h-full w-full object-cover ${beforeAfter === 'before' ? 'object-center grayscale-[.2] brightness-90' : ''}`} /><div className="absolute bottom-5 left-5 bg-[#f3efe7] px-4 py-3 sm:bottom-8 sm:left-8"><p className="eyebrow text-[#c67a55]">{beforeAfter === 'after' ? 'After / botanical canopy' : 'Before / a quiet beginning'}</p></div></motion.div></AnimatePresence><div className="absolute right-4 top-4 hidden items-center gap-2 bg-[#203b37]/80 px-3 py-2 font-mono-brand text-[9px] uppercase tracking-[.1em] text-[#f3efe7] sm:flex"><MoveHorizontal size={14} /> View the shift</div></div>
          </div>
        </section>

        <section id="why" className="bg-[#c67a55] px-5 py-24 text-[#203b37] sm:px-8 sm:py-32 lg:px-12" aria-labelledby="why-title">
          <div className="mx-auto grid max-w-[1380px] gap-14 lg:grid-cols-[.8fr_1.2fr] lg:gap-24">
            <div><p className="eyebrow flex items-center gap-3 text-[#203b37]/70"><span className="h-px w-8 bg-[#203b37]/70" /> Why Parkview</p><h2 id="why-title" className="mt-7 max-w-[400px] font-display text-[clamp(3.5rem,6vw,6.1rem)] leading-[.84] tracking-[-.035em]">The detail is<br /><em>the difference.</em></h2></div>
            <div className="grid gap-8 sm:grid-cols-2">
              {[
                ['Premium designs', 'Curated styles for modern and timeless spaces.'],
                ['Quality first', 'A focus on quality materials and beautiful finishes.'],
                ['Professional guidance', 'Get help selecting designs suitable for your space.'],
                ['Elegant results', 'Transform your walls with sophisticated visual finishes.'],
                ['Customer focused', 'We prioritize customer satisfaction at every step.'],
                ['Local expertise', 'Serving customers in Kanpur and surrounding areas.'],
              ].map(([title, copy], index) => <div key={title} className="border-t border-[#203b37]/35 pt-5"><span className="font-mono-brand text-[10px] text-[#203b37]/60">0{index + 1}</span><h3 className="mt-8 font-display text-3xl">{title}</h3><p className="mt-3 max-w-[240px] text-sm leading-6 text-[#203b37]/70">{copy}</p></div>)}
            </div>
          </div>
        </section>

        <section id="reviews" className="bg-[#203b37] px-5 py-24 text-[#f3efe7] sm:px-8 sm:py-32 lg:px-12" aria-labelledby="testimonial-title">
          <div className="mx-auto max-w-[1180px] text-center">
            <p className="eyebrow text-[#e3af88]">4.8 <span aria-hidden="true">★★★★★</span> · Based on 129 reviews</p><Quote className="mx-auto mt-10 text-[#c67a55]" size={34} strokeWidth={1} />
            <h2 id="testimonial-title" className="mt-6 font-display text-[clamp(2.5rem,5vw,5.2rem)] leading-[.96] tracking-[-.025em]">“A considered space starts<br />with a considered surface.”</h2>
            <p className="mx-auto mt-8 max-w-[490px] text-sm leading-6 text-[#cbd0c6]/65">Testimonial placeholder — replace with an approved client quote before publishing.</p>
            <div className="mx-auto mt-7 flex w-fit items-center gap-3 border-t border-[#e6e3d9]/25 pt-4 font-mono-brand text-[9px] uppercase tracking-[.14em] text-[#e3af88]"><span className="h-1.5 w-1.5 rounded-full bg-[#c67a55]" /> Client name / project type placeholder</div>
            <div className="mt-14 grid gap-4 text-left md:grid-cols-3">
              {['A replaceable customer testimonial placeholder.', 'An approved client review can live here.', 'Add a verified PARKVIEW customer story here.'].map((copy, index) => (
                <div key={copy} className="border border-[#e6e3d9]/20 bg-[#2b4843]/45 p-6">
                  <div className="flex gap-1 text-[#e3af88]" aria-label="Review placeholder">
                    {[1, 2, 3, 4, 5].map((star) => <Star key={star} size={13} fill="currentColor" />)}
                  </div>
                  <p className="mt-6 text-sm leading-6 text-[#e6e3d9]/75">{copy}</p>
                  <p className="mt-8 font-mono-brand text-[9px] uppercase tracking-[.12em] text-[#e3af88]">Placeholder {index + 1} · Replace before publishing</p>
                </div>
              ))}
            </div>
             <a href={googleListingUrl} target="_blank" rel="noreferrer" className="focus-ring mt-10 inline-flex items-center gap-2 border-b border-[#e3af88] pb-2 text-[10px] font-semibold uppercase tracking-[.15em] text-[#e3af88]" data-testid="link-see-more-reviews">Read Google reviews <ArrowUpRight size={14} /></a>
          </div>
        </section>

        <section className="bg-[#f3efe7] px-5 py-24 sm:px-8 sm:py-32 lg:px-12" aria-labelledby="inspiration-title">
          <div className="mx-auto max-w-[1380px]"><div className="flex flex-col justify-between gap-6 md:flex-row md:items-end"><div><p className="eyebrow flex items-center gap-3 text-[#c67a55]"><span className="h-px w-8 bg-[#c67a55]" /> From the studio journal</p><h2 id="inspiration-title" className="mt-7 font-display text-[clamp(3.5rem,6vw,6.1rem)] leading-[.84] tracking-[-.035em]">A little<br /><em>inspiration.</em></h2></div><p className="max-w-[270px] text-sm leading-6 text-[#61706a]">The details that make us stop, look closer and rethink the ordinary wall.</p></div>
            <div className="mt-12 grid grid-cols-2 gap-3 md:grid-cols-4 md:items-end md:gap-5">
              {[['/images/parkview-bedroom.jpg', 'Soft geometry'], ['/images/parkview-exterior.jpg', 'Outside, considered'], ['/images/parkview-office.jpg', 'Work in texture'], ['/images/parkview-texture.jpg', 'The close look']].map(([image, title], index) => <figure key={title} className={`${index % 2 === 1 ? 'md:mb-14' : ''}`}><div className={`${index === 0 ? 'aspect-[.77]' : index === 1 ? 'aspect-[.9]' : index === 2 ? 'aspect-[.76]' : 'aspect-[.9]'} overflow-hidden bg-[#d4c6b5]`}><img src={image} alt={title} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 hover:scale-105" /></div><figcaption className="mt-3 font-mono-brand text-[9px] uppercase tracking-[.12em] text-[#61706a]">{title}</figcaption></figure>)}
            </div>
          </div>
        </section>

        <section id="contact" className="scroll-mt-24 bg-[#e8dfd1] px-5 py-24 sm:px-8 sm:py-32 lg:px-12" aria-labelledby="contact-title">
          <div className="mx-auto grid max-w-[1380px] gap-16 lg:grid-cols-[.9fr_1.1fr] lg:gap-24">
             <div><p className="eyebrow flex items-center gap-3 text-[#c67a55]"><span className="h-px w-8 bg-[#c67a55]" /> Start a conversation</p><h2 id="contact-title" className="mt-7 max-w-[500px] font-display text-[clamp(3.5rem,6vw,6.2rem)] leading-[.84] tracking-[-.035em]">Let’s Transform<br /><em>Your Space</em></h2><p className="mt-8 max-w-[340px] text-sm leading-6 text-[#61706a]">Tell us what you are working on. We will help you find the right next step, whether that is one wall or an entire property.</p><div className="mt-10 space-y-4"><a href="tel:7905531183" className="focus-ring flex w-fit items-center gap-3 text-sm text-[#203b37]" data-testid="link-contact-call"><Phone size={16} className="text-[#c67a55]" /> 7905531183</a><a href="https://wa.me/91905531183" target="_blank" rel="noreferrer" className="focus-ring flex w-fit items-center gap-3 text-sm text-[#203b37]" data-testid="link-contact-whatsapp"><MessageCircle size={16} className="text-[#c67a55]" /> WhatsApp the showroom</a></div></div>
            <div className="bg-[#f3efe7] p-6 sm:p-9 lg:p-12">
               {formSent ? (
                 <div className="flex min-h-[430px] flex-col items-start justify-center">
                   <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#c67a55] text-[#203b37]"><Check size={22} /></div>
                   <h3 className="mt-7 font-display text-4xl">We have your note.</h3>
                   <p className="mt-4 max-w-[350px] text-sm leading-6 text-[#61706a]">Thank you for reaching out. Our showroom team will be in touch soon.</p>
                   <button type="button" onClick={() => setFormSent(false)} className="focus-ring mt-8 border-b border-[#203b37] pb-2 text-[10px] font-semibold uppercase tracking-[.14em]" data-testid="button-send-another-enquiry">Send another enquiry</button>
                 </div>
               ) : (
                 <form onSubmit={submitEnquiry} noValidate>
                   <div className="grid gap-6 sm:grid-cols-2">
                     <label className="block text-[11px] font-semibold uppercase tracking-[.1em] text-[#38524d]">Your name<input value={formState.name} onChange={(event) => updateForm('name', event.target.value)} className="focus-ring mt-3 w-full border-0 border-b border-[#203b37]/25 bg-transparent px-0 py-3 text-base font-normal normal-case tracking-normal text-[#203b37] placeholder:text-[#8a938c]" placeholder="What should we call you?" data-testid="input-enquiry-name" />{formErrors.name && <span className="mt-2 block text-xs font-normal normal-case tracking-normal text-[#a24c3d]">{formErrors.name}</span>}</label>
                     <label className="block text-[11px] font-semibold uppercase tracking-[.1em] text-[#38524d]">Mobile number<input value={formState.phone} onChange={(event) => updateForm('phone', event.target.value)} inputMode="tel" className="focus-ring mt-3 w-full border-0 border-b border-[#203b37]/25 bg-transparent px-0 py-3 text-base font-normal normal-case tracking-normal text-[#203b37] placeholder:text-[#8a938c]" placeholder="10-digit mobile" data-testid="input-enquiry-phone" />{formErrors.phone && <span className="mt-2 block text-xs font-normal normal-case tracking-normal text-[#a24c3d]">{formErrors.phone}</span>}</label>
                     <label className="block text-[11px] font-semibold uppercase tracking-[.1em] text-[#38524d]">Email address<input type="email" value={formState.email} onChange={(event) => updateForm('email', event.target.value)} className="focus-ring mt-3 w-full border-0 border-b border-[#203b37]/25 bg-transparent px-0 py-3 text-base font-normal normal-case tracking-normal text-[#203b37] placeholder:text-[#8a938c]" placeholder="Optional email" data-testid="input-enquiry-email" />{formErrors.email && <span className="mt-2 block text-xs font-normal normal-case tracking-normal text-[#a24c3d]">{formErrors.email}</span>}</label>
                   </div>
                   <label className="mt-7 block text-[11px] font-semibold uppercase tracking-[.1em] text-[#38524d]">Service interested in<select value={formState.project} onChange={(event) => updateForm('project', event.target.value)} className="focus-ring mt-3 w-full border-0 border-b border-[#203b37]/25 bg-transparent px-0 py-3 text-base font-normal normal-case tracking-normal text-[#203b37]" data-testid="select-enquiry-project"><option value="">Choose one</option><option value="home">A home</option><option value="office">An office</option><option value="commercial">A commercial space</option><option value="exterior">An exterior / facade</option></select>{formErrors.project && <span className="mt-2 block text-xs font-normal normal-case tracking-normal text-[#a24c3d]">{formErrors.project}</span>}</label>
                   <label className="mt-7 block text-[11px] font-semibold uppercase tracking-[.1em] text-[#38524d]">Message<textarea value={formState.message} onChange={(event) => updateForm('message', event.target.value)} rows={3} className="focus-ring mt-3 w-full resize-none border-0 border-b border-[#203b37]/25 bg-transparent px-0 py-3 text-base font-normal normal-case tracking-normal text-[#203b37] placeholder:text-[#8a938c]" placeholder="Room, mood, timeline..." data-testid="textarea-enquiry-message" />{formErrors.message && <span className="mt-2 block text-xs font-normal normal-case tracking-normal text-[#a24c3d]">{formErrors.message}</span>}</label>
                   <button type="submit" className="focus-ring group mt-9 flex w-fit items-center gap-6 bg-[#203b37] px-5 py-4 text-[10px] font-semibold uppercase tracking-[.16em] text-[#f3efe7] transition-transform hover:-translate-y-1" data-testid="button-submit-enquiry">Send enquiry <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" /></button>
                   <p className="mt-4 text-[11px] leading-5 text-[#61706a]">We only use these details to reply to your enquiry.</p>
                 </form>
               )}
            </div>
          </div>
        </section>

        <section className="bg-[#d4c6b5] px-5 py-20 sm:px-8 lg:px-12" aria-labelledby="visit-title">
          <div className="mx-auto grid max-w-[1380px] gap-10 lg:grid-cols-[.7fr_1.3fr] lg:items-center"><div><p className="eyebrow flex items-center gap-3 text-[#c67a55]"><span className="h-px w-8 bg-[#c67a55]" /> Find the studio</p><h2 id="visit-title" className="mt-7 font-display text-[clamp(3.2rem,5vw,5.2rem)] leading-[.85] tracking-[-.035em]">Come see it<br /><em>in the light.</em></h2><p className="mt-6 max-w-[310px] text-sm leading-6 text-[#38524d]">67/3, Near Mithas Sweets,<br />Site No. 1, Juhi Kalan,<br />Kidwai Nagar, Kanpur,<br />Uttar Pradesh 208011</p><div className="mt-7 flex flex-wrap gap-4"><a href="https://www.google.com/maps/search/?api=1&query=67%2F3%2C%20Near%20Mithas%20Sweets%2C%20Site%20No.%201%2C%20Juhi%20Kalan%2C%20Kidwai%20Nagar%2C%20Kanpur%2C%20Uttar%20Pradesh%20208011" target="_blank" rel="noreferrer" className="focus-ring flex items-center gap-2 bg-[#203b37] px-4 py-3 text-[10px] font-semibold uppercase tracking-[.14em] text-[#f3efe7]" data-testid="link-get-directions">Get directions <ExternalLink size={14} /></a><span className="flex items-center gap-2 px-1 py-3 font-mono-brand text-[9px] uppercase tracking-[.12em] text-[#61706a]"><Clock3 size={14} /> Call for showroom hours</span></div></div><div className="relative min-h-[300px] overflow-hidden border border-[#203b37]/15 bg-[#203b37] p-5 sm:min-h-[380px]"><div className="absolute inset-0 opacity-35" style={{ backgroundImage: 'linear-gradient(rgba(243,239,231,.2) 1px, transparent 1px), linear-gradient(90deg, rgba(243,239,231,.2) 1px, transparent 1px)', backgroundSize: '52px 52px' }} /><div className="relative flex h-full min-h-[260px] items-center justify-center"><div className="flex flex-col items-center text-center text-[#f3efe7]"><MapPin size={30} strokeWidth={1.2} className="text-[#c67a55]" /><p className="mt-3 font-display text-3xl">PARKVIEW</p><p className="eyebrow mt-2 text-[#e3af88]">Site No. 1 · Juhi Kalan</p><p className="mt-5 max-w-[240px] text-xs leading-5 text-[#cbd0c6]/70">Map preview unavailable? Use the directions link to open this address in Google Maps.</p></div></div></div></div>
        </section>

        <section className="relative overflow-hidden bg-[#203b37] px-5 py-24 text-[#f3efe7] sm:px-8 sm:py-32 lg:px-12" aria-labelledby="final-cta-title">
          <img src="/images/parkview-exterior.jpg" alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-25" />
          <div className="absolute inset-0 bg-[#102c29]/80" />
          <div className="relative mx-auto flex max-w-[1380px] flex-col justify-between gap-10 md:flex-row md:items-end">
            <div><p className="eyebrow text-[#e3af88]">Your next room starts here</p><h2 id="final-cta-title" className="mt-7 max-w-[850px] font-display text-[clamp(3.5rem,7vw,7.5rem)] leading-[.78] tracking-[-.045em]">Ready to Give Your<br /><em>Walls a New Identity?</em></h2><p className="mt-8 max-w-[430px] text-sm leading-6 text-[#e6e3d9]/75">Explore premium wallpaper and interior solutions from PARKVIEW.</p></div>
            <div className="flex flex-wrap gap-4">
              <a href="tel:7905531183" className="focus-ring group flex w-fit items-center gap-5 bg-[#c67a55] px-5 py-4 text-[10px] font-semibold uppercase tracking-[.16em] text-[#203b37] transition-transform hover:-translate-y-1" data-testid="link-final-call">Call 7905531183 <Phone size={16} /></a>
              <a href="https://www.google.com/maps/search/?api=1&query=67%2F3%2C%20Near%20Mithas%20Sweets%2C%20Site%20No.%201%2C%20Juhi%20Kalan%2C%20Kidwai%20Nagar%2C%20Kanpur%2C%20Uttar%20Pradesh%20208011" target="_blank" rel="noreferrer" className="focus-ring flex w-fit items-center gap-3 border border-[#e6e3d9]/50 px-5 py-4 text-[10px] font-semibold uppercase tracking-[.16em] text-[#f3efe7] hover:border-[#e3af88]" data-testid="link-final-directions">Get directions <ExternalLink size={15} /></a>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-[#102c29] px-5 py-12 text-[#f3efe7] sm:px-8 lg:px-12"><div className="mx-auto max-w-[1380px]"><div className="grid gap-12 border-b border-[#e6e3d9]/15 pb-12 md:grid-cols-[1.2fr_.8fr_.8fr]"><div><div className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center border border-[#c67a55] text-[#c67a55]"><span className="font-display text-2xl leading-none">P</span></span><span><span className="block text-[13px] font-semibold tracking-[.18em]">PARKVIEW</span><span className="block font-mono-brand text-[9px] uppercase tracking-[.13em] text-[#9ba39a]">Interior + Exterior</span></span></div><p className="mt-6 max-w-[290px] text-sm leading-6 text-[#cbd0c6]/65">A material-first showroom for homes, offices and commercial spaces in Kanpur.</p><p className="mt-4 max-w-[290px] text-xs leading-5 text-[#cbd0c6]/55">67/3, Near Mithas Sweets, Site No. 1, Juhi Kalan, Kidwai Nagar, Kanpur, Uttar Pradesh 208011</p></div><div><p className="eyebrow text-[#e3af88]">Explore</p><div className="mt-5 space-y-3 text-sm text-[#cbd0c6]/75"><button type="button" onClick={() => scrollToSection('top')} className="focus-ring block hover:text-[#f3efe7]" data-testid="button-footer-home">Home</button><button type="button" onClick={() => scrollToSection('about')} className="focus-ring block hover:text-[#f3efe7]" data-testid="button-footer-about">About</button><button type="button" onClick={() => scrollToSection('collection')} className="focus-ring block hover:text-[#f3efe7]" data-testid="button-footer-collection">Wallpapers</button><button type="button" onClick={() => scrollToSection('services')} className="focus-ring block hover:text-[#f3efe7]" data-testid="button-footer-services">Services</button><button type="button" onClick={() => scrollToSection('reviews')} className="focus-ring block hover:text-[#f3efe7]" data-testid="button-footer-reviews">Reviews</button><button type="button" onClick={() => scrollToSection('contact')} className="focus-ring block hover:text-[#f3efe7]" data-testid="button-footer-contact">Contact</button></div></div><div><p className="eyebrow text-[#e3af88]">Stay in touch</p><div className="mt-5 space-y-3 text-sm text-[#cbd0c6]/75"><a href="tel:7905531183" className="focus-ring block hover:text-[#f3efe7]" data-testid="link-footer-phone">7905531183</a><a href="https://wa.me/91905531183" target="_blank" rel="noreferrer" className="focus-ring block hover:text-[#f3efe7]" data-testid="link-footer-whatsapp">WhatsApp</a><a href="https://www.instagram.com/" target="_blank" rel="noreferrer" className="focus-ring flex w-fit items-center gap-2 hover:text-[#f3efe7]" data-testid="link-footer-instagram"><Instagram size={15} /> Instagram</a></div></div></div><div className="flex flex-col justify-between gap-3 pt-6 font-mono-brand text-[9px] uppercase tracking-[.1em] text-[#9ba39a] sm:flex-row"><p>© 2026 PARKVIEW Interior and Exterior Solutions. All Rights Reserved.</p><p>Kanpur, Uttar Pradesh</p></div></div></footer>

       <a href="https://wa.me/91905531183" target="_blank" rel="noreferrer" title="Chat with us on WhatsApp" className="focus-ring fixed bottom-5 right-5 z-30 flex items-center gap-3 rounded-full bg-[#c67a55] px-4 py-3 text-[10px] font-semibold uppercase tracking-[.12em] text-[#203b37] shadow-[0_10px_28px_rgba(20,49,45,.2)] transition-transform hover:-translate-y-1 sm:bottom-7 sm:right-7" data-testid="link-floating-whatsapp" aria-label="Chat on WhatsApp"><MessageCircle size={18} /> <span className="hidden sm:inline">WhatsApp the showroom</span></a>

      <AnimatePresence>
        {lightbox && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center bg-[#102c29]/90 p-5 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label={`${lightbox.title} preview`} onClick={() => setLightbox(null)}><motion.div initial={{ scale: .96, y: 12 }} animate={{ scale: 1, y: 0 }} exit={{ scale: .96, y: 12 }} className="relative max-h-[90vh] w-full max-w-[900px] bg-[#f3efe7] p-2 sm:p-3" onClick={(event) => event.stopPropagation()}><button type="button" onClick={() => setLightbox(null)} className="focus-ring absolute right-3 top-3 z-10 flex h-9 w-9 items-center justify-center bg-[#203b37] text-[#f3efe7]" aria-label="Close image preview" data-testid="button-close-lightbox"><X size={18} /></button><img src={lightbox.image} alt={`${lightbox.title}, ${lightbox.note}`} className="max-h-[72vh] w-full object-contain" /><div className="flex items-end justify-between px-3 pb-2 pt-4"><div><p className="font-display text-3xl text-[#203b37]">{lightbox.title}</p><p className="eyebrow mt-1 text-[#c67a55]">{lightbox.note}</p></div><button type="button" onClick={() => { setLightbox(null); scrollToSection('contact'); }} className="focus-ring hidden items-center gap-2 border-b border-[#203b37] pb-2 text-[10px] font-semibold uppercase tracking-[.14em] text-[#203b37] sm:flex" data-testid="button-lightbox-enquire">Ask about this look <ArrowUpRight size={14} /></button></div></motion.div></motion.div>}
      </AnimatePresence>
    </div>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;